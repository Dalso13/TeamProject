package org.worldfinder.controller;

public class MypageController {

}
