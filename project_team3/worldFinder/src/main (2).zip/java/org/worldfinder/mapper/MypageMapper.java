package org.worldfinder.mapper;

public interface MypageMapper {

}
