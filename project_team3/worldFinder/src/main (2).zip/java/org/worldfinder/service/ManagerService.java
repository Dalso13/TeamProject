package org.worldfinder.service;

public interface ManagerService {

}
