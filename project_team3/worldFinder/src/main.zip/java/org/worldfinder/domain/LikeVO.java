package org.worldfinder.domain;

public class LikeVO {

}
