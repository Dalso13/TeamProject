package org.worldfinder.domain;

public class CommentVO {

}
