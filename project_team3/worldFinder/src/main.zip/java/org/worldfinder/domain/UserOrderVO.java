package org.worldfinder.domain;

public class UserOrderVO {

}
