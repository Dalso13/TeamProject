create view EMP_TESTVIEW as
select "T_IDX","T_WRITER","TITLE","FIRST_C_TITLE","FIRST_C","SECOND_C_TITLE","SECOND_C","THIRD_C_TITLE","THIRD_C","EMAGE","HIT","CARTEGORY","SEMI_CARTEGORY","MY_DATE" from my_table where cartegory = '아시아'
/

