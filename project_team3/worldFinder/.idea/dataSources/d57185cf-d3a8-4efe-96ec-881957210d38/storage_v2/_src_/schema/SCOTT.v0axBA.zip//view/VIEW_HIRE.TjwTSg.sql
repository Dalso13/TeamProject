create view VIEW_HIRE as
SELECT EMPNO, ename, hiredate
FROM EMP
ORDER BY hiredate
/

