create view SNOW_WHITE as
select bookname, price from test_book
/

